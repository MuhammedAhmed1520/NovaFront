<template>
  <div class="dashboard">
    <h1 class="subheading grey--text">dashboard</h1>
  </div>
</template>

<script>
export default {};
</script>
